import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score



data_train = pd.read_csv('training_set.csv')
data_test = pd.read_csv('test_set.csv')

# label_encoder = LabelEncoder()
# print(data_train['Payment_Behaviour'].value_counts())
occupation_list = {'Engineer': 0,
       'Lawyer': 1,
       'Mechanic': 2,
       'Developer': 3,
       'Accountant': 4,
       'Architect': 5,
       'Entrepreneur': 6,
       'Journalist': 7,
       'Scientist': 8,
       'Media_Manager': 9,
       'Teacher': 10,
       'Doctor': 11,
       'Musician': 12,
       'Manager': 13,
       'Writer': 14
}
# creidt_list={'Good':0,'Standard':1,'Poor':2}
Credit_Mix_list={'Good':0,
                 'Standard':1,
                 'Bad':2
}
Payment_of_Min_Amount_list={'Yes':1,
                            'No':2,
                            'NM':0
}
Payment_Behaviour_list={'Low_spent_Small_value_payments':0,
                        'High_spent_Medium_value_payments':1,
                        'High_spent_Large_value_payments':2,
                        'Low_spent_Medium_value_payments':3,
                        'High_spent_Small_value_payments':4,
                        'Low_spent_Large_value_payments':5
}


data_train['Occupation'] = data_train['Occupation'].map(occupation_list)
data_train['Credit_Mix']=data_train['Credit_Mix'].map(Credit_Mix_list)
data_train['Payment_of_Min_Amount']=data_train['Payment_of_Min_Amount'].map(Payment_of_Min_Amount_list)
data_train['Payment_Behaviour']=data_train['Payment_Behaviour'].map(Payment_Behaviour_list)
data_train_selected=data_train[['Occupation','Annual_Income','Monthly_Inhand_Salary','Num_Bank_Accounts','Num_Credit_Card','Interest_Rate','Num_of_Loan','Delay_from_due_date','Num_of_Delayed_Payment','Changed_Credit_Limit','Num_Credit_Inquiries','Credit_Mix','Outstanding_Debt','Credit_Utilization_Ratio','Credit_History_Age','Payment_of_Min_Amount','Total_EMI_per_month','Amount_invested_monthly','Payment_Behaviour','Monthly_Balance','Credit_Score']]

data_test['Occupation'] = data_test['Occupation'].map(occupation_list)
data_test['Credit_Mix']=data_test['Credit_Mix'].map(Credit_Mix_list)
data_test['Payment_of_Min_Amount']=data_test['Payment_of_Min_Amount'].map(Payment_of_Min_Amount_list)
data_test['Payment_Behaviour']=data_test['Payment_Behaviour'].map(Payment_Behaviour_list)
data_test_selected=data_test[['Occupation','Annual_Income','Monthly_Inhand_Salary','Num_Bank_Accounts','Num_Credit_Card','Interest_Rate','Num_of_Loan','Delay_from_due_date','Num_of_Delayed_Payment','Changed_Credit_Limit','Num_Credit_Inquiries','Credit_Mix','Outstanding_Debt','Credit_Utilization_Ratio','Credit_History_Age','Payment_of_Min_Amount','Total_EMI_per_month','Amount_invested_monthly','Payment_Behaviour','Monthly_Balance']]


# print(data_train_selected['Credit_Mix'])
data_train_selected_data = data_train_selected.iloc[:, :-1]
data_train_selected_label = data_train_selected.iloc[:, -1]

scaler = StandardScaler()
data_train_selected_data = scaler.fit_transform(data_train_selected_data)
data_test_selected=scaler.fit_transform(data_test_selected)


X_train, X_test, y_train, y_test = train_test_split(data_train_selected_data, data_train_selected_label, test_size=0.02, random_state=654654)


my_model = KNeighborsClassifier(n_neighbors=10, weights='distance', algorithm='ball_tree', p=1)


my_model.fit(data_train_selected_data,data_train_selected_label)



y_pred = my_model.predict(data_test_selected)
print(y_pred)
for i in y_pred:
       print(i)
# for i in y_test:
#        print(i)


# accuracy = accuracy_score(y_test, y_pred)
# print(f'Accuracy: {accuracy}')
